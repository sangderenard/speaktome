from __future__ import annotations

import math
import unittest

import numpy as np

from openrgb_dt_spirograph import (
    RADIAL_DIRECTIONS,
    adaptive_path_phases,
    bake_contribution_lut,
    contribution_matrix,
    hypotrochoid_point,
    hypotrochoid_repeat_period,
    radial_contributions,
)


class RadialContributionTests(unittest.TestCase):
    def test_center_is_dim_and_uniform(self) -> None:
        np.testing.assert_allclose(radial_contributions(0.0, 0.0), np.full(8, 0.25))

    def test_perimeter_alignment_has_half_intensity_direct_neighbors(self) -> None:
        point = tuple(RADIAL_DIRECTIONS[5])  # installed right side
        row = radial_contributions(*point)
        self.assertAlmostEqual(row[5], 1.0)
        self.assertAlmostEqual(row[4], 0.5)
        self.assertAlmostEqual(row[6], 0.5)
        self.assertAlmostEqual(row[3], 0.0)
        self.assertAlmostEqual(row[7], 0.0)

    def test_quarter_center_contribution_conserves_total_driver_weight(self) -> None:
        for radius in np.linspace(0.0, 1.0, 9):
            for angle in np.linspace(-math.pi, math.pi, 33):
                row = radial_contributions(
                    radius * math.cos(angle), radius * math.sin(angle)
                )
                self.assertAlmostEqual(float(np.sum(row)), 2.0, places=12)

    def test_arbitrary_sites_generate_float_matrix(self) -> None:
        matrix = contribution_matrix(((0.0, 0.0), (1.0, 0.0), (0.2, -0.3)))
        self.assertEqual(matrix.shape, (3, 8))
        self.assertTrue(np.issubdtype(matrix.dtype, np.floating))
        self.assertTrue(np.all((0.0 <= matrix) & (matrix <= 1.0)))

    def test_outside_point_keeps_unit_direction_without_lobe_broadening(self) -> None:
        np.testing.assert_allclose(
            radial_contributions(10.0, 0.0),
            radial_contributions(1.0, 0.0),
        )

    def test_adaptive_sites_respect_eight_bit_step(self) -> None:
        phases = adaptive_path_phases(color_bits=8)
        points = [hypotrochoid_point(float(phase)) for phase in phases]
        matrix = contribution_matrix(points)
        maximum_step = float(np.max(np.abs(np.diff(matrix, axis=0))))
        self.assertLessEqual(maximum_step, 1.0 / 255.0 + 1.0e-12)
        self.assertGreater(len(phases), 256)
        self.assertAlmostEqual(float(phases[0]), 0.0)
        self.assertAlmostEqual(float(phases[-1]), 6.0 * math.pi)

    def test_lut_closes_at_repeat_epsilon(self) -> None:
        self.assertAlmostEqual(hypotrochoid_repeat_period(), 6.0 * math.pi)
        lut = bake_contribution_lut(color_bits=8, repeat_epsilon=1.0e-9)
        self.assertLessEqual(lut.repeat_error, 1.0e-9)
        self.assertTrue(lut.saturated)
        self.assertIsNone(lut.cutoff_reason)
        np.testing.assert_allclose(lut.contributions[0], lut.contributions[-1], atol=1.0e-9)

    def test_lut_returns_complete_cycle_when_dynamic_budget_cuts_off(self) -> None:
        lut = bake_contribution_lut(color_bits=12, max_sites=65)
        self.assertFalse(lut.saturated)
        self.assertEqual(lut.cutoff_reason, "site_budget")
        self.assertAlmostEqual(float(lut.phases[0]), 0.0)
        self.assertAlmostEqual(float(lut.phases[-1]), 6.0 * math.pi)
        self.assertLessEqual(lut.repeat_error, 1.0e-9)


if __name__ == "__main__":
    unittest.main()
