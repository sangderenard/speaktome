# Thin OpenRGB full-frame shell

This directory provides a deliberately small Python interface to an already-running OpenRGB SDK server. It does not start OpenRGB, install a driver, rescan hardware, create a service, change a firewall rule, or write anything on import.

The wrapper exposes the underlying `client` and `device` objects, but its supported write path is intentionally narrow: select a mode explicitly and send one complete controller frame. This is important for the ASRock Polychrome USB driver, whose zone and single-LED SDK methods collapse to one whole-zone color. Its only per-position packet path is the full-device `UpdateLEDs()` operation used by `device.set_colors(...)`.

## Current hardware evidence

- ASRock B650M Pro RS WiFi is reached through USB HID `26CE:01A2`.
- One clean all-zone `Static` `400000` test produced red on the cooler and motherboard.
- One clean all-zone `Static` `202020` test produced white on both. The apparently pale-red motherboard was the colored backing plate seen through white illumination, not an RGB channel error.
- Direct full-frame writes are verified on `Addressable Header 3/Audio`.
- That zone advertises 80 logical positions, but the measured cooler/fan chain uses positions 0 through 7. In the installed, upside-down view the radial map is `0=bottom-left`, `1=left`, `2=top-left`, `3=top`, `4=top-right`, `5=right`, `6=bottom-right`, and `7=bottom`. Increasing positions walk clockwise.
- Logical red appears physically green and logical green appears physically red on this chain, establishing an R/G channel swap. White is unaffected.
- The motherboard `PCB` zone has four independently addressed backside LEDs: position 0 appears above the board, while positions 1 through 3 appear along its right side.
- No GPU is present in the current OpenRGB SDK device inventory; the 245 mapped addresses all belong to the motherboard controller.
- The 80-entry header listing is configured logical capacity, not a physical LED census. Parallel splitter outputs still mirror and cannot be made independent in software.

## Environment

Use the repository's documented environment setup rather than installing into
the system interpreter. `requirements.txt` bounds the maintained SDK client to
`openrgb-python>=0.3.7,<0.4`; it does not install an RGB driver or a background
service. The managed-dt effects additionally use the adjacent `turing/`
checkout. Their eight-band display basis is imported from the adjacent
`spectral-analyzer/` ray tracer, so the light field and tracer use the same
700-to-400 nm band ordering and band-to-linear-RGB response.

## Start exactly one loopback-only OpenRGB server

First exit ASRock Polychrome completely and verify that `AsrPolychromeRGB.exe` and old `OpenRGB.exe` instances are absent. Then, in a separate terminal, start the reviewed portable OpenRGB build with the existing isolated configuration:

```powershell
& 'C:\Users\alber\AppData\Local\Temp\OpenRGB-1.0-81bbe18\OpenRGB Windows 64-bit\OpenRGB.exe' `
  --config 'C:\Users\alber\AppData\Local\Temp\OpenRGB-1.0-total-coordination-20261003' `
  --noautoconnect `
  --server `
  --server-host 127.0.0.1 `
  --server-port 6742
```

Pinned OpenRGB 1.0 source confirms that `--server-host` is passed to the server and that its documented default is also `127.0.0.1`. Keep the explicit loopback argument. This wrapper refuses a non-loopback host unless `--allow-remote` is supplied. No firewall rule is required or recommended.

Starting OpenRGB initializes the USB lighting controller once. Leave that one process running while programming; repeated CLI launches repeat initialization and global writes.

## Inventory and dry runs

Inventory sends no lighting update and lists every SDK device, each zone, its
dense law-domain offset, and the controller-provided addresses in that region:

```powershell
.\.venv\Scripts\python.exe .\openrgb_shell.py --device-name 'ASRock B650M Pro RS WiFi' inventory
```

All mutating CLI operations are dry runs unless `--apply` is present:

```powershell
.\.venv\Scripts\python.exe .\openrgb_shell.py --device-name 'ASRock B650M Pro RS WiFi' `
  solid --mode Static --rgb 32 32 32
```

## Minimal one-position mapping test

Use the fresh inventory name/index rather than assuming that Polychrome's `Addressable RGB LED3` equals an earlier OpenRGB zone number. The following constructs a full black controller frame with one dim-red logical position. Without `--apply`, it only validates and prints the plan:

```powershell
.\.venv\Scripts\python.exe .\openrgb_shell.py --device-name 'ASRock B650M Pro RS WiFi' `
  pixel --mode Direct --zone 'Addressable Header 3/Audio' --position 0 --rgb 64 0 0
```

After checking the inventory and accepting the Direct-mode risk, append `--apply` once. Stop if the result is a pattern, mirrored devices, no isolated point, or an unexpected motherboard change. If position zero isolates correctly, move one position at a time and record the physical result.

Direct mode is a capability test here, not established support. Entering it and sending a frame are hardware writes; the ASRock driver updates the complete controller even when the logical target is one header.

## Python API

```python
from openrgb_shell import connect

rgb = connect(device_name="ASRock B650M Pro RS WiFi")

for zone in rgb.zones:
    print(zone.index, zone.name, zone.start, zone.count, zone.addresses)

for address in rgb.address_domain:
    print(address)

rgb.select_mode("Direct")
frame = rgb.pixel_frame("Addressable Header 3/Audio", 0, (64, 0, 0))
rgb.send_frame(frame)

# Escape hatches, if needed:
raw_client = rgb.client
raw_device = rgb.device
```

`address_domain` is the explicit boundary between arbitrary controller identity
and numerical law identity. Every entry preserves the system address, region
name/index, position within that region, and full-frame slot while assigning a
dense `domain_index` from `0` through `N - 1`.

## Managed-dt LLVM linear walk

`openrgb_dt_walk.py` implements the first animation law:

1. Project the controller's arbitrary addresses and regions onto the dense
   `domain_index` described above.
2. Author the cursor, wrap, and RGB state as simultaneous SymPy equations.
3. Compile that law through the repository's generated AbstractTensor stage
   and LLVM piece route.
4. Instantiate one persistent Turing dt system. Each display frame is exactly
   one `advance_round` window; the law publishes both `max_vel` and `dt_limit`.
5. Convert the resulting RGB columns back through `frame_index` and send one
   complete controller frame.

The default is one full dry-run pass at five addresses per second. Because the
law speed is `fps` addresses/second and each managed window is `1/fps` seconds,
the white point advances by exactly one dense address per frame:

```powershell
py .\openrgb_dt_walk.py --device-name 'ASRock B650M Pro RS WiFi' --fps 5
```

The dry run prints the dense index and its preserved region/system identities.
It compiles and advances the real LLVM/dt path, but sends no hardware update.
After the one-position Direct-mode mapping test has succeeded, an explicit
finite hardware run is:

```powershell
py .\openrgb_dt_walk.py --device-name 'ASRock B650M Pro RS WiFi' `
  --mode Direct --fps 5 --frames 20 --white-level 255 --apply
```

For the measured eight-slice cooler/fan chain on Header 3, project only those
active positions into the dense compiler domain. Nine frames demonstrate one
complete pass and the wrap back to position zero:

```powershell
py .\openrgb_dt_walk.py --device-name 'ASRock B650M Pro RS WiFi' `
  --zone 'Addressable Header 3/Audio' --position-count 8 `
  --mode Direct --fps 2 --frames 9 --white-level 128 --apply
```

Use `--start-position 1` to phase this installed radial map at the left-side
midpoint, producing the observed `left -> top-left -> top -> top-right -> right
-> bottom-right -> bottom -> bottom-left` pass.

The symbolic law remains independent of this wiring calibration. `--zone` and
`--position-count` choose the measured system addresses before assigning dense
law indices; generated colors are still returned in a black 245-slot full
controller frame.

`--apply` selects the requested mode once and sends complete frames through the
existing `FullFrameController`. There is no retry, daemon, or background
service. Stop immediately if the controller mirrors, patterns, or affects an
unexpected physical site.

Do not use `rgb.device.zones[n].set_colors(...)` or `rgb.device.zones[n].leds[m].set_color(...)` for this ASRock controller. Those SDK operations reach driver methods that transmit only a zone's first color rather than its per-LED array.

## Offline verification

Tests use fake devices and make no socket or hardware call:

```powershell
py -m unittest -v test_openrgb_shell.py test_openrgb_dt_walk.py
```

## Continuous radial spirograph locator

`openrgb_dt_spirograph.py` treats the calibrated eight-light ring as a
continuous float field. For point `p` and light direction `u_i`, it evaluates
`center * (1 - radius) + radius * max(0, normalize(p) dot u_i)^2`. At the
perimeter this gives the aligned light `1.0`, both direct 45-degree neighbors
`0.5`, and perpendicular/opposite lights `0.0`. At the exact center every
light receives the same dim center contribution.

The spatial row is now the first matrix in a spectral pipeline. The white
source is a nonnegative eight-band spectrum selected to project to equal
linear RGB through the spectral ray tracer's response. Spectral power is
accumulated before display conversion; RGB is never used as the transported
field representation. With `center=0.25`, every point contributes a constant
total driver weight of `2.0` across the eight lights.

Evaluating that analytic generator at arbitrary sites produces an `N x 8`
contribution matrix; the sites are not the model's spatial discretization. An
optional LUT bake adaptively subdivides one complete hypotrochoid repeat until
adjacent rows differ by no more than one selected color-code step. The default
`R=5, r=3` path repeats after `6*pi`, not `2*pi`. Site and wall-time budgets
cut off long bakes dynamically and report the achieved epsilon without
claiming saturation.

The verified 60 Hz live command is:

```powershell
py .\openrgb_dt_spirograph.py --device-name 'ASRock B650M Pro RS WiFi' `
  --zone 'Addressable Header 3/Audio' --position-count 8 `
  --fps 60 --frames 300 --angular-speed 1 --center-contribution 0.25 `
  --white-level 96 --exposure 3 --color-bits 8 --apply
```

The 2026-10-03 five-second live run achieved 59.996 Hz with zero deadline
misses. Total work was 3.184 ms at p95 and 10.387 ms maximum; SDK send time was
0.467 ms at p95. The Python process used 14.69% of one core, OpenRGB used
0.14% of one core, system CPU averaged 7.92% and peaked at 11.79%, and OpenRGB
working-set growth was 0 MiB. The 8-bit LUT saturated at 2,916 sites with a
maximum adjacent float step of 0.00391839 and repeat error of `1.665e-16`.

## Chaotic CMY three-body field

`openrgb_dt_three_body.py` integrates three freely gravitating masses under the
managed dt system. It uses Burrau's chaotic Pythagorean initial condition:
masses `3, 4, 5`, initially stationary at the vertices of a scaled `3:4:5`
triangle. There are no prescribed tracks or phase-driven orbits.

Cyan, magenta, and yellow are nonnegative spectra on the ray tracer's eight
wavelength bands. Cyan and yellow are single spectral lines; magenta is an
explicit red-plus-violet composite. Each integrated planet position generates
its own continuous eight-light radial row. At each light the symbolic law
evaluates the matrix product
`(1x3 source weights) @ (3x8 source spectra) @ (8x3 display response)`.
The first multiplication is the field: pure and composite spectra add there
before any RGB projection. The final linear HDR RGB is passed through a smooth
exponential exposure curve rather than a per-channel hard clip, so overlaps do
not collapse immediately into an indistinguishable white plateau.

One instantaneous shared radius normalizes the three positions,
preserving relative radial placement while ensuring the outermost source
reaches the unit field. Direction normalization is independent, so escaping
bodies cannot broaden or overdrive the angular lobe. The measured Header 3
red/green swap is corrected at the final full-frame boundary.

```powershell
py .\openrgb_dt_three_body.py --device-name 'ASRock B650M Pro RS WiFi' `
  --zone 'Addressable Header 3/Audio' --position-count 8 `
  --fps 60 --frames 600 --brightness 96 --center-contribution 0.25 `
  --exposure 3 --apply
```

The ten-second live run achieved 59.999 Hz with zero deadline misses. Total
work was 3.028 ms at p95 and 5.685 ms maximum; SDK send time was 0.395 ms at
p95, and the Python process used 16.72% of one core.

Those live timings predate the spectral matrix update. An offline native
120-frame measurement of the updated compiled laws produced 1.56 ms/frame for
spirograph and 1.62 ms/frame for three-body, excluding one-time compilation.
Both laws lowered through `AbstractTensor` to LLVM with zero shortfalls.
The updated spectral three-body law was then run live for 300 frames: 59.995
Hz, zero deadline misses, 2.632 ms median work, 3.099 ms p95 work, 4.871 ms
maximum work, 0.416 ms p95 SDK send time, and 16.56% of one CPU core. Its
first compilation in a fresh process remains a separate, substantial startup
cost; it is not part of those frame timings.

Both effects can be selected through one entry point without changing their
managed-dt engines:

```powershell
py .\openrgb_dt_field.py spirograph <spirograph options>
py .\openrgb_dt_field.py three-body <three-body options>
```
