from __future__ import annotations

import unittest

import numpy as np

from openrgb_dt_three_body import _grb_wire_frame
from openrgb_spectral_field import (
    CMY_SPECTRA,
    WHITE_SPECTRUM,
    accumulate_spectral_field,
    raytracer_display_matrix,
    spectral_field_to_linear_rgb,
)


class ThreeBodyColorTests(unittest.TestCase):
    def test_cmy_are_nonnegative_spectra_in_raytracer_basis(self) -> None:
        self.assertEqual(CMY_SPECTRA.shape, (3, 8))
        self.assertTrue(np.all(CMY_SPECTRA >= 0.0))
        linear_rgb = CMY_SPECTRA @ raytracer_display_matrix()
        np.testing.assert_allclose(linear_rgb[0, 0], 0.0, atol=1.0e-12)
        np.testing.assert_allclose(linear_rgb[1], (1.0, 0.0, 1.0), atol=1.0e-12)
        np.testing.assert_allclose(linear_rgb[2, 2], 0.0, atol=1.0e-12)

    def test_spectra_add_before_display_projection(self) -> None:
        kernel = np.asarray(((0.25, 0.5, 0.75), (1.0, 0.0, 0.5)))
        field = accumulate_spectral_field(kernel, CMY_SPECTRA)
        direct = spectral_field_to_linear_rgb(field)
        expected = kernel @ (CMY_SPECTRA @ raytracer_display_matrix())
        np.testing.assert_allclose(direct, expected, atol=1.0e-12)

    def test_composite_magenta_retains_two_spectral_lines(self) -> None:
        active = np.flatnonzero(CMY_SPECTRA[1] > 0.0)
        np.testing.assert_array_equal(active, (1, 7))

    def test_spirograph_white_is_a_spectrum_not_three_rgb_constants(self) -> None:
        self.assertGreater(np.count_nonzero(WHITE_SPECTRUM), 1)
        np.testing.assert_allclose(
            WHITE_SPECTRUM @ raytracer_display_matrix(),
            (1.0, 1.0, 1.0),
            atol=1.0e-12,
        )

    def test_grb_wire_compensation_swaps_red_and_green(self) -> None:
        self.assertEqual(_grb_wire_frame([(10, 20, 30)]), [(20, 10, 30)])


if __name__ == "__main__":
    unittest.main()
