"""Canonical radial and spectral field algebra for OpenRGB effects.

The spectral-analyzer ray tracer transports wavelength bands and postpones its
display reduction until after band accumulation.  This module keeps that
contract for the LED field: ``K @ S`` first, then ``spectrum @ RGB_weights``.
The matrices are authored with SymPy for the compiled path and NumPy for
inspection/tests; both use the ray tracer's eight-band display basis.
"""

from __future__ import annotations

from functools import lru_cache
import math
from pathlib import Path
import sys
from typing import Sequence

import numpy as np
import sympy as sp


HERE = Path(__file__).resolve().parent
WORKSPACE = HERE.parents[2]
SPECTRAL_ANALYZER_ROOT = WORKSPACE / "spectral-analyzer"

SPECTRAL_WAVELENGTHS_NM = np.linspace(700.0, 400.0, 8, dtype=np.float64)
RADIAL_ANGLES = np.asarray(
    (-3.0 * math.pi / 4.0, math.pi, 3.0 * math.pi / 4.0, math.pi / 2.0,
     math.pi / 4.0, 0.0, -math.pi / 4.0, -math.pi / 2.0),
    dtype=np.float64,
)
RADIAL_DIRECTIONS = np.column_stack((np.cos(RADIAL_ANGLES), np.sin(RADIAL_ANGLES)))


@lru_cache(maxsize=1)
def raytracer_display_matrix() -> np.ndarray:
    """Return the ray tracer's eight-band to linear-display-RGB matrix."""

    if not SPECTRAL_ANALYZER_ROOT.is_dir():
        raise RuntimeError(
            f"spectral-analyzer is required at {SPECTRAL_ANALYZER_ROOT}"
        )
    inserted = False
    root = str(SPECTRAL_ANALYZER_ROOT)
    if root not in sys.path:
        sys.path.insert(0, root)
        inserted = True
    try:
        # scene_orders states and tests that this is byte-for-byte the native
        # ray tracer's band_to_display_rgb transfer.
        from scene_orders import _display_rgb_weights

        matrix = np.asarray(
            _display_rgb_weights(SPECTRAL_WAVELENGTHS_NM), dtype=np.float64
        )
    finally:
        if inserted:
            sys.path.remove(root)
    if matrix.shape != (8, 3) or not np.isfinite(matrix).all():
        raise RuntimeError("spectral-analyzer returned an invalid 8x3 display matrix")
    matrix.setflags(write=False)
    return matrix


def default_cmy_spectra() -> np.ndarray:
    """Three nonnegative ray-tracer-band spectra for cyan, magenta, yellow.

    Cyan and yellow are single-band spectral colours.  Magenta is explicitly
    composite: red plus violet, demonstrating that non-spectral colours remain
    a distribution until the final display projection.
    """

    display = raytracer_display_matrix()
    spectra = np.zeros((3, 8), dtype=np.float64)

    cyan_band = 5
    spectra[0, cyan_band] = 1.0 / float(np.max(display[cyan_band]))

    red_band, violet_band = 1, 7
    spectra[1, violet_band] = 1.0 / float(display[violet_band, 2])
    red_remainder = 1.0 - spectra[1, violet_band] * display[violet_band, 0]
    spectra[1, red_band] = red_remainder / float(display[red_band, 0])

    yellow_band = 3
    spectra[2, yellow_band] = 1.0 / float(np.max(display[yellow_band]))
    return spectra


def equal_display_white_spectrum() -> np.ndarray:
    """Nonnegative three-line spectrum projecting to linear RGB (1, 1, 1)."""

    display = raytracer_display_matrix()
    active = np.asarray((1, 4, 6), dtype=np.int64)
    weights = np.linalg.solve(display[active].T, np.ones(3, dtype=np.float64))
    if np.any(weights < 0.0):
        raise RuntimeError("ray-tracer display basis no longer admits the white spectrum")
    spectrum = np.zeros(8, dtype=np.float64)
    spectrum[active] = weights
    return spectrum


CMY_SPECTRA = default_cmy_spectra()
WHITE_SPECTRUM = equal_display_white_spectrum()


def radial_contributions(
    x: float,
    y: float,
    *,
    center_contribution: float = 0.25,
) -> np.ndarray:
    """Generate the continuous eight-light contribution row for one point."""

    if not np.isfinite((x, y, center_contribution)).all():
        raise ValueError("point and center contribution must be finite")
    if not 0.0 <= center_contribution <= 1.0:
        raise ValueError("center_contribution must be in the inclusive range 0..1")
    distance = math.hypot(float(x), float(y))
    radial = min(1.0, distance)
    if distance == 0.0:
        return np.full(8, float(center_contribution), dtype=np.float64)
    direction = np.asarray((x / distance, y / distance), dtype=np.float64)
    alignment = np.maximum(0.0, RADIAL_DIRECTIONS @ direction)
    return np.clip(
        center_contribution * (1.0 - radial) + radial * alignment * alignment,
        0.0,
        1.0,
    )


def symbolic_radial_kernel(x, y, direction_x, direction_y, center_contribution):
    """SymPy authority for the radial driver field used by every effect."""

    distance = sp.sqrt(x**2 + y**2)
    radial = sp.Min(sp.Integer(1), distance)
    safe_distance = sp.Max(distance, sp.Float(1.0e-12))
    alignment = (x * direction_x + y * direction_y) / safe_distance
    directional = sp.Max(sp.Integer(0), alignment) ** 2
    return sp.Min(
        sp.Integer(1),
        center_contribution * (sp.Integer(1) - radial) + radial * directional,
    )


def accumulate_spectral_field(
    contributions: Sequence[Sequence[float]],
    source_spectra: Sequence[Sequence[float]],
) -> np.ndarray:
    """Matrix field accumulation: ``(lights,sources) @ (sources,bands)``."""

    kernel = np.asarray(contributions, dtype=np.float64)
    spectra = np.asarray(source_spectra, dtype=np.float64)
    if kernel.ndim != 2 or spectra.ndim != 2 or kernel.shape[1] != spectra.shape[0]:
        raise ValueError("contributions and spectra must have shapes (L,S) and (S,B)")
    if spectra.shape[1] != 8:
        raise ValueError("spectra must use the ray tracer's eight-band basis")
    if not np.isfinite(kernel).all() or not np.isfinite(spectra).all():
        raise ValueError("field matrices must be finite")
    if np.any(kernel < 0.0) or np.any(spectra < 0.0):
        raise ValueError("spectral field coefficients must be nonnegative")
    return kernel @ spectra


def spectral_field_to_linear_rgb(field_spectrum: Sequence[Sequence[float]]) -> np.ndarray:
    """Project an accumulated ``(lights,8)`` spectrum to HDR linear RGB."""

    spectrum = np.asarray(field_spectrum, dtype=np.float64)
    if spectrum.ndim != 2 or spectrum.shape[1] != 8:
        raise ValueError("field spectrum must have shape (lights,8)")
    if not np.isfinite(spectrum).all() or np.any(spectrum < 0.0):
        raise ValueError("field spectrum must be finite and nonnegative")
    return spectrum @ raytracer_display_matrix()


def symbolic_spectral_display(
    source_weights: sp.MatrixBase,
    source_spectra: sp.MatrixBase,
    *,
    exposure,
    output_level,
) -> tuple[sp.Expr, sp.Expr, sp.Expr]:
    """Accumulate spectral matrices and map HDR linear RGB to LED drive.

    The exponential exposure is applied only after spectral addition.  It is
    monotone and asymptotic, so overlap remains distinguishable instead of
    becoming a hard-clipped white plateau.
    """

    weights = sp.Matrix(source_weights)
    spectra = sp.Matrix(source_spectra)
    if weights.cols != 1 or spectra.rows != weights.rows or spectra.cols != 8:
        raise ValueError("symbolic shapes must be weights=(sources,1), spectra=(sources,8)")
    display = sp.ImmutableDenseMatrix(raytracer_display_matrix().tolist())
    field_spectrum = weights.T * spectra
    linear_rgb = field_spectrum * display
    channels = []
    for channel in range(3):
        positive = sp.Max(sp.Integer(0), linear_rgb[0, channel])
        mapped = sp.Integer(1) - sp.exp(-exposure * positive)
        channels.append(output_level * mapped)
    return tuple(channels)


__all__ = [
    "CMY_SPECTRA", "RADIAL_ANGLES", "RADIAL_DIRECTIONS",
    "SPECTRAL_WAVELENGTHS_NM", "WHITE_SPECTRUM",
    "accumulate_spectral_field", "default_cmy_spectra",
    "equal_display_white_spectrum", "radial_contributions",
    "raytracer_display_matrix", "spectral_field_to_linear_rgb",
    "symbolic_radial_kernel", "symbolic_spectral_display",
]
