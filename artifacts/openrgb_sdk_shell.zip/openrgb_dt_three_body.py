"""Compiled three-body CMY spectral field for the calibrated eight-light ring."""

from __future__ import annotations

import argparse
from functools import lru_cache
import math
from pathlib import Path
import statistics
import sys
import time
from typing import Sequence

import numpy as np
import sympy as sp

from openrgb_spectral_field import (
    CMY_SPECTRA,
    RADIAL_DIRECTIONS,
    symbolic_radial_kernel,
    symbolic_spectral_display,
)
from openrgb_dt_walk import (
    AddressDomain,
    TURING_ROOT,
    address_domain_for,
    advance_managed_state,
    instantiate_managed_piece,
)
from openrgb_shell import OpenRGBShellError, connect


@lru_cache(maxsize=1)
def compile_three_body_law():
    """Author gravity plus matrix-accumulated CMY spectral projection."""

    from src.compiler.symbolic_equation_compiler import compile_sympy_equations

    direction_x, direction_y, gravity, softening, center, brightness, exposure, dt = sp.symbols(
        "direction_x direction_y gravity softening center_contribution brightness exposure dt"
    )
    positions = [sp.symbols(f"x{i} y{i}") for i in range(3)]
    velocities = [sp.symbols(f"vx{i} vy{i}") for i in range(3)]
    masses = list(sp.symbols("mass0 mass1 mass2"))
    spectra = sp.Matrix(3, 8, lambda source, band: sp.Symbol(f"spectrum{source}_b{band}"))

    accelerations: list[tuple[sp.Expr, sp.Expr]] = []
    for i in range(3):
        ax: sp.Expr = sp.Integer(0)
        ay: sp.Expr = sp.Integer(0)
        xi, yi = positions[i]
        for j in range(3):
            if i == j:
                continue
            xj, yj = positions[j]
            dx, dy = xj - xi, yj - yi
            inv_r3 = (dx**2 + dy**2 + softening**2) ** sp.Rational(-3, 2)
            ax += gravity * masses[j] * dx * inv_r3
            ay += gravity * masses[j] * dy * inv_r3
        accelerations.append((ax, ay))

    next_velocities = [
        (velocities[i][0] + accelerations[i][0] * dt,
         velocities[i][1] + accelerations[i][1] * dt)
        for i in range(3)
    ]
    next_positions = [
        (positions[i][0] + next_velocities[i][0] * dt,
         positions[i][1] + next_velocities[i][1] * dt)
        for i in range(3)
    ]
    radii = [sp.sqrt(x_value**2 + y_value**2) for x_value, y_value in next_positions]
    field_radius = sp.Max(*radii, sp.Float(1.0e-12))
    field_positions = [
        (x_value / field_radius, y_value / field_radius)
        for x_value, y_value in next_positions
    ]
    weights = [
        symbolic_radial_kernel(*field_positions[i], direction_x, direction_y, center)
        for i in range(3)
    ]
    rgb = symbolic_spectral_display(
        sp.Matrix(weights), spectra, exposure=exposure, output_level=brightness,
    )
    speeds = [sp.sqrt(vx**2 + vy**2) for vx, vy in next_velocities]
    max_speed = sp.Max(*speeds, sp.Float(1.0e-12))
    equations: list[sp.Equality] = []
    for index, ((x_next, y_next), (vx_next, vy_next)) in enumerate(
        zip(next_positions, next_velocities)
    ):
        equations.extend((
            sp.Eq(sp.Symbol(f"x{index}_next"), x_next, evaluate=False),
            sp.Eq(sp.Symbol(f"y{index}_next"), y_next, evaluate=False),
            sp.Eq(sp.Symbol(f"vx{index}_next"), vx_next, evaluate=False),
            sp.Eq(sp.Symbol(f"vy{index}_next"), vy_next, evaluate=False),
        ))
    equations.extend((
        sp.Eq(sp.Symbol("red_next"), rgb[0], evaluate=False),
        sp.Eq(sp.Symbol("green_next"), rgb[1], evaluate=False),
        sp.Eq(sp.Symbol("blue_next"), rgb[2], evaluate=False),
        sp.Eq(sp.Symbol("dt_limit"), sp.Min(sp.Float(0.02), 1 / max_speed), evaluate=False),
        sp.Eq(sp.Symbol("max_vel"), max_speed, evaluate=False),
    ))
    return compile_sympy_equations(tuple(equations), name="openrgb_three_body_spectral")


def compile_three_body_piece(*, directory: Path | None = None):
    from src.compiler.native_package import piece_from_law

    build = directory or (TURING_ROOT / "build" / "openrgb_three_body_spectral" / "8")
    return piece_from_law(
        compile_three_body_law(),
        "openrgb_three_body_spectral",
        8,
        directory=build,
    )


class ManagedThreeBodyField:
    """Persistent managed-dt three-body state projected onto eight lights."""

    def __init__(
        self,
        domain: AddressDomain,
        *,
        frames_per_second: float = 60.0,
        center_contribution: float = 0.25,
        brightness: int = 96,
        exposure: float = 3.0,
        gravity: float = 1.0,
        softening: float = 0.02,
        piece=None,
    ) -> None:
        if domain.count != 8:
            raise ValueError("The calibrated radial field requires exactly eight addresses")
        if frames_per_second <= 0.0 or not math.isfinite(frames_per_second):
            raise ValueError("frames_per_second must be finite and positive")
        if not 0.0 <= center_contribution <= 1.0:
            raise ValueError("center_contribution must be in the inclusive range 0..1")
        if not 0 <= brightness <= 255:
            raise ValueError("brightness must be in the inclusive range 0..255")
        if not math.isfinite(exposure) or exposure <= 0.0:
            raise ValueError("exposure must be finite and positive")
        if softening <= 0.0:
            raise ValueError("softening must be positive")

        self.domain = domain
        self.frame_seconds = 1.0 / float(frames_per_second)
        self.piece = piece or compile_three_body_piece()
        count = domain.count
        # Burrau's chaotic Pythagorean three-body problem, scaled into the ring.
        # Pairwise distances retain the 3:4:5 relationship; all bodies start at rest.
        initial_positions = (
            (0.25, 0.75),
            (-0.50, -0.25),
            (0.25, -0.25),
        )
        initial_velocities = (
            (0.0, 0.0),
            (0.0, 0.0),
            (0.0, 0.0),
        )
        initial_masses = (3.0, 4.0, 5.0)
        columns = {
            "direction_x": RADIAL_DIRECTIONS[:, 0].copy(),
            "direction_y": RADIAL_DIRECTIONS[:, 1].copy(),
            "gravity": np.full(count, gravity, dtype=np.float64),
            "softening": np.full(count, softening, dtype=np.float64),
            "center_contribution": np.full(count, center_contribution, dtype=np.float64),
            "brightness": np.full(count, float(brightness), dtype=np.float64),
            "exposure": np.full(count, float(exposure), dtype=np.float64),
        }
        for i in range(3):
            columns[f"x{i}"] = np.full(count, initial_positions[i][0], dtype=np.float64)
            columns[f"y{i}"] = np.full(count, initial_positions[i][1], dtype=np.float64)
            columns[f"vx{i}"] = np.full(count, initial_velocities[i][0], dtype=np.float64)
            columns[f"vy{i}"] = np.full(count, initial_velocities[i][1], dtype=np.float64)
            columns[f"mass{i}"] = np.full(count, initial_masses[i], dtype=np.float64)
            for band in range(8):
                columns[f"spectrum{i}_b{band}"] = np.full(
                    count, CMY_SPECTRA[i, band], dtype=np.float64
                )
        columns.update({
            "red": np.zeros(count, dtype=np.float64),
            "green": np.zeros(count, dtype=np.float64),
            "blue": np.zeros(count, dtype=np.float64),
        })
        self.state = instantiate_managed_piece(
            self.piece,
            columns,
            self.frame_seconds,
            label="openrgb-three-body-cmy",
        )

    def advance_frame(self) -> list[tuple[int, int, int]]:
        advance_managed_state(self.state, self.frame_seconds)
        return self.domain.frame_from_channels(self.state.red, self.state.green, self.state.blue)


def _grb_wire_frame(frame: Sequence[tuple[int, int, int]]) -> list[tuple[int, int, int]]:
    """Compensate the measured Header 3 physical red/green swap."""

    return [(green, red, blue) for red, green, blue in frame]


def _percentile(values: list[float], fraction: float) -> float:
    ordered = sorted(values)
    return ordered[min(len(ordered) - 1, int(math.ceil(fraction * len(ordered))) - 1)]


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--device-name", required=True)
    parser.add_argument("--zone", required=True)
    parser.add_argument("--position-count", type=int, default=8)
    parser.add_argument("--mode", default="Direct")
    parser.add_argument("--fps", type=float, default=60.0)
    parser.add_argument("--frames", type=int, default=300)
    parser.add_argument("--brightness", type=int, default=96)
    parser.add_argument("--center-contribution", type=float, default=0.25)
    parser.add_argument("--exposure", type=float, default=3.0)
    parser.add_argument("--apply", action="store_true")
    return parser


def main(argv: Sequence[str] | None = None) -> int:
    args = _build_parser().parse_args(argv)
    try:
        if args.frames <= 0:
            raise ValueError("frames must be positive")
        controller = connect(device_name=args.device_name)
        try:
            zone_selector: int | str = int(args.zone)
        except ValueError:
            zone_selector = args.zone
        domain = address_domain_for(controller, zone_selector, position_count=args.position_count)
        field = ManagedThreeBodyField(
            domain,
            frames_per_second=args.fps,
            center_contribution=args.center_contribution,
            brightness=args.brightness,
            exposure=args.exposure,
        )
        if args.apply:
            controller.select_mode(args.mode)
        work_times: list[float] = []
        send_times: list[float] = []
        misses = 0
        started = time.perf_counter()
        cpu_started = time.process_time()
        for frame_number in range(args.frames):
            work_started = time.perf_counter()
            frame = field.advance_frame()
            if args.apply:
                send_started = time.perf_counter()
                controller.send_frame(_grb_wire_frame(frame))
                send_times.append(time.perf_counter() - send_started)
            work_times.append(time.perf_counter() - work_started)
            deadline = started + (frame_number + 1) * field.frame_seconds
            now = time.perf_counter()
            misses += now > deadline
            time.sleep(max(0.0, deadline - now))
        elapsed = time.perf_counter() - started
        cpu_elapsed = time.process_time() - cpu_started
        print(
            "benchmark "
            f"frames={args.frames} target_hz={args.fps:.3f} achieved_hz={args.frames / elapsed:.3f} "
            f"deadline_misses={misses} work_ms_p50={statistics.median(work_times)*1000:.3f} "
            f"work_ms_p95={_percentile(work_times,0.95)*1000:.3f} "
            f"work_ms_max={max(work_times)*1000:.3f} "
            f"send_ms_p95={(_percentile(send_times,0.95)*1000 if send_times else 0.0):.3f} "
            f"process_cpu_percent={100.0*cpu_elapsed/elapsed:.2f}"
        )
        if not args.apply:
            print("Dry run: no hardware update sent")
        return 0
    except (OpenRGBShellError, RuntimeError, TypeError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
